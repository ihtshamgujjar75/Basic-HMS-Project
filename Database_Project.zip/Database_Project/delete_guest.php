<?php
include "connect.php";

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    $sql = "DELETE FROM Guests WHERE guest_id = $id";

    if (mysqli_query($conn, $sql)) {
        header('Location: view_guests.php');
        exit();
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
} else {
    echo "No ID provided.";
}

mysqli_close($conn);
?>
