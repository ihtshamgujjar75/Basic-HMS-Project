<?php
include "connect.php";

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    $result = mysqli_query($conn, "SELECT * FROM students WHERE id = $id");

    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
    } else {
        echo "Record not found.";
    }
} else {
    echo "No ID provided.";
}

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $address = $_POST['address'];

    $sql = "UPDATE students SET name = '$name', email = '$email', Phone = '$phone', address = '$address' WHERE id = $id";

    if (mysqli_query($conn, $sql)) {
        header('Location: select.php');
        exit();
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Record</title>
    <style>
        body {
            font-family: lato;
            margin: 0;
            padding: 0;
            background-image: url('5.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            color: white;
            height: 100vh;
        }
        form {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 20px;
            border-radius: 8px;
            width: 25%;
            margin: 80px auto;
        }
        input {
            display: block;
            width: 100%;
            margin-bottom: 20px;
            padding: 5px;
            box-sizing: border-box;
        }
        .button {
            background-color: red;
            color: white;
        }
        .button:hover {
            background-color: gray;
            color: white;
        }
    </style>
</head>
<body>
    <form action="edit.php?id=<?php echo $id; ?>" method="post">
        <fieldset>
            <legend>Edit Record</legend>
            Name:
            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($row['name']); ?>" required>
            Phone:
            <input type="tel" id="phone" name="phone" value="<?php echo htmlspecialchars($row['Phone']); ?>" required>
            Email:
            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($row['email']); ?>" required>
            City:
            <input type="text" id="Address" name="City" value="<?php echo htmlspecialchars($row['city']); ?>" required>
            Zipcode:
            <input type="text" id="zip" name="zip" value="<?php echo htmlspecialchars($row['zip']); ?>" required>
          
            State:
            <input type="text" id="Address" name="state" value="<?php echo htmlspecialchars($row['state']); ?>"  required>
          
            <input type="submit" value="Update" class="button">
        </fieldset>
    </form>
</body>
</html>
