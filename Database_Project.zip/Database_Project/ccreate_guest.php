<?php
include "connect.php";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
    $last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $contact = mysqli_real_escape_string($conn, $_POST['contact']);
    $city = mysqli_real_escape_string($conn, $_POST['city']);
    $state = mysqli_real_escape_string($conn, $_POST['state']);
    $zipCode = mysqli_real_escape_string($conn, $_POST['zipCode']);

    $sql = "INSERT INTO Guests (First_name, Last_name, Email, contact, city, state, zipCode)
            VALUES ('$first_name', '$last_name', '$email', '$contact', '$city', '$state', '$zipCode')";

    if (mysqli_query($conn, $sql)) {
        $guest_id = mysqli_insert_id($conn); // Get the last inserted guest ID
        header("Location: guestconfirmation.php?guest_id=" . urlencode($guest_id));
        exit();
    } else {
        echo "Error inserting data: " . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Guest</title>
    <style>
        body { font-family: 'Lato', sans-serif; margin: 0; padding: 0; background-image: url('5.jpg'); background-size: cover; background-repeat: no-repeat; color: white; height: 100vh; }
        form { background-color: rgba(0, 0, 0, 0.7); padding: 20px; border-radius: 8px; width: 25%; margin: 80px auto; }
        input { display: block; width: 100%; margin-bottom: 20px; padding: 5px; box-sizing: border-box; }
        .button { background-color: red; color: white; }
        .button:hover { background-color: gray; color: white; }
    </style>
</head>
<body>
    <form action="ccreate_guest.php" method="post">
        <fieldset>
            <legend>Create New Guest</legend>
            First Name: <input type="text" name="first_name" required>
            Last Name: <input type="text" name="last_name" required>
            Email: <input type="email" name="email" required>
            Contact: <input type="tel" name="contact" required>
            City: <input type="text" name="city" required>
            State: <input type="text" name="state" required>
            Zip Code: <input type="text" name="zipCode" required>
            <input type="submit" value="Submit" class="button">
        </fieldset>
    </form>
</body>
</html>
