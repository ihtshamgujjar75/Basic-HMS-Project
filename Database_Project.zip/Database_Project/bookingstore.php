<?php
include "connect.php";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $guest_id = intval($_POST['guest_id']);
    $room_id = intval($_POST['room_id']);
    $check_in = mysqli_real_escape_string($conn, $_POST['check_in']);
    $check_out = mysqli_real_escape_string($conn, $_POST['check_out']);
    $booking_date = mysqli_real_escape_string($conn, $_POST['booking_date']);
    $payment_status = mysqli_real_escape_string($conn, $_POST['payment_status']);

    $sql = "INSERT INTO Booking (guest_id, room_id, Check_in, check_out, Booking_date, payment_status) 
            VALUES ('$guest_id', '$room_id', '$check_in', '$check_out', '$booking_date', '$payment_status')";

    if (mysqli_query($conn, $sql)) {
        $booking_id = mysqli_insert_id($conn); // Get the last inserted booking ID
        header("Location: confirmation.php?booking_id=$booking_id");
        exit();
    } else {
        echo "Error inserting data: " . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>
