<?php
include "connect.php";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $room_number = intval($_POST['room_number']);
    $room_type = mysqli_real_escape_string($conn, $_POST['room_type']);
    $rate_per_night = intval($_POST['rate_per_night']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);
    $guest_id = intval($_POST['guest_id']);
   
    $sql = "INSERT INTO Rooms (room_number, room_type, rate_per_night, Status, Location, guest_id) 
            VALUES ('$room_number', '$room_type', '$rate_per_night', '$status', '$location', '$guest_id')";

    if (mysqli_query($conn, $sql)) {
        header('Location: select_room.php');
        exit();
    } else {
        echo "Error inserting data: " . mysqli_error($conn);
    }
}

$guest_id = isset($_GET['guest_id']) ? intval($_GET['guest_id']) : 0;

mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Room</title>
    <style>
        body {
            font-family: lato;
            margin: 0;
            padding: 0;
            background-image: url('5.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            color: white;
            height: 100vh;
        }
        form {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 20px;
            border-radius: 8px;
            width: 30%;
            margin: 80px auto;
        }
        input, select {
            display: block;
            width: 100%;
            margin-bottom: 20px;
            padding: 5px;
            box-sizing: border-box;
        }
        .button {
            background-color: red;
            color: white;
        }
        .button:hover {
            background-color: gray;
            color: white;
        }
    </style>
</head>
<body>
    <form action="add_room.php" method="post">
        <fieldset>
            <legend>Add Room</legend>
            Room Number:
            <input type="number" id="room_number" name="room_number" placeholder="Room Number" required>
            Room Type:
            <input type="text" id="room_type" name="room_type" placeholder="Room Type" required>
            Rate Per Night:
            <input type="number" id="rate_per_night" name="rate_per_night" placeholder="Rate Per Night" required>
            Status:
            <input type="text" id="status" name="status" placeholder="Status" required>
            Location:
            <input type="text" id="location" name="location" placeholder="Location" required>
            Guest ID :
            <input type="number" id="guest_id" name="guest_id" value="<?php echo $guest_id; ?>">
           
            <input type="submit" value="Add Room" class="button">
        </fieldset>
    </form>
</body>
</html>
