<?php
include "connect.php";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    // Collect and sanitize form data
    $rating = intval($_POST['rating']);
    $comments = mysqli_real_escape_string($conn, $_POST['comments']);
    $booking_id = intval($_POST['booking_id']);
    $guest_id = intval($_POST['guest_id']);
    $feedback_date = date('Y-m-d H:i:s');  // Current date and time

    // Insert query
    $sql = "INSERT INTO feedback (rating, comments, booking_id, feedback_date, guest_id) 
            VALUES ('$rating', '$comments', '$booking_id', '$feedback_date', '$guest_id')";

    // Execute query and handle errors
    if (mysqli_query($conn, $sql)) {
        header('Location: submittedfeedback.html');
        exit();
    } else {
        echo "<p>Error inserting data: " . mysqli_error($conn) . "</p>";
    }
}

// Close the database connection
mysqli_close($conn);
?>
