<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Feedback</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: #f4f4f4;
            color: #333;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            width: 50%;
            margin: 40px auto;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        input, textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button[type="submit"] {
            background-color: #28a745;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button[type="submit"]:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <form action="store_feedback.php" method="post">
        <fieldset>
            <legend>Submit Feedback</legend>
            Rating (1-5):
            <input type="number" id="rating" name="rating" min="1" max="5" required>
            Comments:
            <textarea id="comments" name="comments" rows="4" required></textarea>
            Booking ID:
            <input type="number" id="booking_id" name="booking_id" placeholder="Booking ID" required>
            Guest ID:
            <input type="number" id="guest_id" name="guest_id" placeholder="Guest ID" required>
            Feedback Date:
            <input type="datetime-local" id="feedback_date" name="feedback_date">
            <button type="submit">Submit Feedback</button>
        </fieldset>
    </form>
</body>
</html>
