<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Booking</title>
    <style>
        body {
            font-family: lato;
            margin: 0;
            padding: 0;
            background-image: url('5.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            color: white;
            height: 100vh;
        }
        form {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 20px;
            border-radius: 8px;
            width: 30%;
            margin: 80px auto;
        }
        input, select {
            display: block;
            width: 100%;
            margin-bottom: 20px;
            padding: 5px;
            box-sizing: border-box;
        }
        .button {
            background-color: red;
            color: white;
        }
        .button:hover {
            background-color: gray;
            color: white;
        }
    </style>
</head>
<body>
    <form action="store_booking.php" method="post">
        <fieldset>
            <legend>Create Booking</legend>
            Guest ID:
            <input type="number" id="guest_id" name="guest_id" placeholder="Guest ID" required>
            Room ID:
            <input type="number" id="room_id" name="room_id" placeholder="Room ID" required>
            Check-in Date:
            <input type="date" id="check_in" name="check_in" placeholder="Check-in Date" required>
            Check-out Date:
            <input type="date" id="check_out" name="check_out" placeholder="Check-out Date" required>
            Booking Date:
            <input type="date" id="booking_date" name="booking_date" placeholder="Booking Date" required>
            Payment Status:
            <select id="payment_status" name="payment_status" required>
                <option value="Paid">Paid</option>
                <option value="Unpaid">Unpaid</option>
            </select>
            <input type="submit" value="Add Booking" class="button">
        </fieldset>
    </form>
</body>
</html>
