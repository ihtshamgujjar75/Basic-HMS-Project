<?php
include "connect.php";

// Fetch existing record if ID is provided
$bill_id = isset($_GET['bill_id']) ? intval($_GET['bill_id']) : 0;

if ($bill_id > 0) {
    // Prepare and execute the query to fetch the record
    $stmt = mysqli_prepare($conn, "SELECT * FROM billings WHERE bill_id = ?");
    mysqli_stmt_bind_param($stmt, "i", $bill_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) == 1) {
        $record = mysqli_fetch_assoc($result);
    } else {
        echo "Record not found.";
        exit();
    }
    mysqli_stmt_close($stmt);
} else {
    echo "Invalid ID.";
    exit();
}

// Handle form submission for updating
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $booking_id = mysqli_real_escape_string($conn, $_POST['booking_id']);
    $total_amount = mysqli_real_escape_string($conn, $_POST['total_amount']);
    $payment_date = mysqli_real_escape_string($conn, $_POST['payment_date']);
    $payment_method = mysqli_real_escape_string($conn, $_POST['payment_method']);
    $advance = mysqli_real_escape_string($conn, $_POST['advance']);
    $guest_id = mysqli_real_escape_string($conn, $_POST['guest_id']);

    // Prepare and execute the query to update the record
    $stmt = mysqli_prepare($conn, "UPDATE billings SET booking_id = ?, Total_amount = ?, payment_date = ?, payment_method = ?, advance = ?, guest_id = ? WHERE bill_id = ?");
    mysqli_stmt_bind_param($stmt, "idssiii", $booking_id, $total_amount, $payment_date, $payment_method, $advance, $guest_id, $bill_id);

    if (mysqli_stmt_execute($stmt)) {
        header('Location: manage_billings.php');
        exit();
    } else {
        echo "<p>Error updating record: " . mysqli_error($conn) . "</p>";
    }
    mysqli_stmt_close($stmt);
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Billing</title>
    <style>
        body {
            font-family: lato;
            margin: 0;
            padding: 0;
            background-image: url('5.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            color: white;
            height: 100vh;
        }
        form {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 20px;
            border-radius: 8px;
            width: 30%;
            margin: 80px auto;
        }
        input {
            display: block;
            width: 100%;
            margin-bottom: 20px;
            padding: 5px;
            box-sizing: border-box;
        }
        .button {
            background-color: red;
            color: white;
        }
        .button:hover {
            background-color: gray;
            color: white;
        }
    </style>
</head>
<body>
    <form action="update_billing.php?bill_id=<?php echo $bill_id; ?>" method="post">
        <fieldset>
            <legend>Update Billing</legend>
            Booking ID:
            <input type="number" id="booking_id" name="booking_id" value="<?php echo htmlspecialchars($record['booking_id']); ?>" placeholder="Booking ID" required>
            Total Amount:
            <input type="number" id="total_amount" name="total_amount" value="<?php echo htmlspecialchars($record['Total_amount']); ?>" placeholder="Total Amount" required>
            Payment Date:
            <input type="date" id="payment_date" name="payment_date" value="<?php echo htmlspecialchars($record['payment_date']); ?>" required>
            Payment Method:
            <input type="text" id="payment_method" name="payment_method" value="<?php echo htmlspecialchars($record['payment_method']); ?>" placeholder="Payment Method" required>
            Advance:
            <input type="number" id="advance" name="advance" value="<?php echo htmlspecialchars($record['advance']); ?>" placeholder="Advance Amount" required>
            Guest ID:
            <input type="number" id="guest_id" name="guest_id" value="<?php echo htmlspecialchars($record['guest_id']); ?>" placeholder="Guest ID" required>
            <input type="submit" value="Update Billing" class="button">
        </fieldset>
    </form>
</body>
</html>
