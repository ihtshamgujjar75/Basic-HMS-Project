<?php
include "connect.php";

// Initialize variables for form values
$room_number = '';
$room_type = '';
$rate_per_night = '';
$status = '';
$location = '';
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    // Sanitize and get POST data
    $room_number = mysqli_real_escape_string($conn, $_POST['room_number']);
    $room_type = mysqli_real_escape_string($conn, $_POST['room_type']);
    $rate_per_night = mysqli_real_escape_string($conn, $_POST['rate_per_night']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);

    if ($id > 0) {
        // Update existing room
        $sql = "UPDATE Rooms SET room_number = '$room_number', room_type = '$room_type', rate_per_night = '$rate_per_night', Status = '$status', Location = '$location' WHERE room_id = $id";
        
        if (mysqli_query($conn, $sql)) {
            header('Location: view_rooms.php');
            exit();
        } else {
            echo "Error updating record: " . mysqli_error($conn);
        }
    } else {
        // Insert new room
        $sql = "INSERT INTO Rooms (room_number, room_type, rate_per_night, Status, Location)
                VALUES ('$room_number', '$room_type', '$rate_per_night', '$status', '$location')";
        
        if (mysqli_query($conn, $sql)) {
            header('Location: view_rooms.php');
            exit();
        } else {
            echo "Error inserting data: " . mysqli_error($conn);
        }
    }
} elseif ($id > 0) {
    // Fetch existing room data for editing
    $result = mysqli_query($conn, "SELECT * FROM Rooms WHERE room_id = $id");
    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        $room_number = htmlspecialchars($row['room_number']);
        $room_type = htmlspecialchars($row['room_type']);
        $rate_per_night = htmlspecialchars($row['rate_per_night']);
        $status = htmlspecialchars($row['Status']);
        $location = htmlspecialchars($row['Location']);
    } else {
        echo "Record not found.";
        exit();
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $id > 0 ? "Edit Room" : "Create Room"; ?></title>
    <style>
        body { font-family: 'Lato', sans-serif; margin: 0; padding: 0; background-image: url('5.jpg'); background-size: cover; background-repeat: no-repeat; color: white; height: 100vh; }
        form { background-color: rgba(0, 0, 0, 0.7); padding: 20px; border-radius: 8px; width: 25%; margin: 80px auto; }
        input { display: block; width: 100%; margin-bottom: 20px; padding: 5px; box-sizing: border-box; }
        .button { background-color: red; color: white; }
        .button:hover { background-color: gray; color: white; }
    </style>
</head>
<body>
    <form action="create_update_room.php<?php echo $id > 0 ? '?id=' . $id : ''; ?>" method="post">
        <fieldset>
            <legend><?php echo $id > 0 ? "Edit Room" : "Create New Room"; ?></legend>
            Room Number: <input type="number" name="room_number" value="<?php echo $room_number; ?>" required>
            Room Type: <input type="text" name="room_type" value="<?php echo $room_type; ?>" required>
            Rate per Night: <input type="number" name="rate_per_night" value="<?php echo $rate_per_night; ?>" required>
            Status: <input type="text" name="status" value="<?php echo $status; ?>" required>
            Location: <input type="text" name="location" value="<?php echo $location; ?>" required>
            <input type="submit" value="<?php echo $id > 0 ? 'Update' : 'Submit'; ?>" class="button">
        </fieldset>
    </form>
</body>
</html>
