<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: admin_login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('hotel.JPG'); 
            background-size: cover; 
            background-position: center; 
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            height: 100vh;
            color: white; 
        }

        .header {
            width: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            padding: 15px 20px;
            position: fixed;
            top: 0;
            left: 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
            z-index: 1000;
        }

        .header h1 {
            margin: 0;
            font-size: 28px;
        }

        .header .logout {
            background-color: #dc3545;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            font-size: 18px;
            transition: background-color 0.3s;
        }

        .header .logout:hover {
            background-color: #c82333;
        }

        .container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
            width: 80%;
            max-width: 1000px;
            margin-top: 100px; /* Adjust based on header height */
            padding: 20px;
        }

        .box {
            width: 220px;
            height: 160px;
            background-color: #007bff;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            font-size: 20px;
            text-decoration: none;
            transition: background-color 0.3s;
        }

        .box:hover {
            background-color: #0056b3;
        }

        .box a {
            color: white;
            text-decoration: none;
            display: block;
            width: 100%;
            height: 100%;
            line-height: 160px;
        }

        .boxb {
            width: 120px;
            height: 120px;
            background-color: red;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            font-size: 20px;
            text-decoration: none;
            transition: background-color 0.3s;
            margin-top: 20px;
        }
        
        .boxb a {
            color: white;
            text-decoration: none;
            display: block;
            width: 100%;
            height: 100%;
            line-height: 120px;
        }

        .boxb:hover {
            background-color: #d9534f;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Admin Dashboard</h1>
        <a href="logout.php" class="logout">Logout</a>
    </div>

    <div class="container">

    <div class="box">
            <a href="form.php">Create Guest</a>
        </div>

        <div class="box">
            <a href="view_guests.php">view Guest</a>
        </div>


        <div class="box">
            <a href="create_room.php">Create Room</a>
        </div>

       
        <div class="box">
            <a href="select_room.php">view Rooms</a>
        </div>
        <div class="box">
            <a href="create_booking.php">Add Booking</a>
        </div>

        <div class="box">
            <a href="view_bookings.php">view Booking</a>
        </div>
        <div class="box">
            <a href="create_billing.php">Generate Billings</a>
        </div>

       
        <div class="box">
            <a href="create_housekeeping.html">Add Housekeeping</a>
        </div>

        <div class="box">
            <a href="manage_housekeeping.php">view Housekeeping</a>
        </div>
        <div class="box">
            <a href="view_feedback.php">View Feedback</a>
        </div>
    </div>

</body>
</html>
