<?php
include "connect.php";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    // Collect and sanitize form data
    $room_id = intval($_POST['room_id']);
    $schedule_date = mysqli_real_escape_string($conn, $_POST['schedule_date']);
    $housekeeper_name = mysqli_real_escape_string($conn, $_POST['housekeeper_name']);
    $task_description = mysqli_real_escape_string($conn, $_POST['task_description']);
    $schedule_status = mysqli_real_escape_string($conn, $_POST['schedule_status']);

    // Insert query
    $sql = "INSERT INTO housekeepingschedule (room_id, schedule_date, housekeeper_name, Task_description, schedule_status)
            VALUES ('$room_id', '$schedule_date', '$housekeeper_name', '$task_description', '$schedule_status')";

    // Execute query and handle errors
    if (mysqli_query($conn, $sql)) {
        header('Location: manage_housekeeping.php');
        exit();
    } else {
        echo "<p>Error inserting data: " . mysqli_error($conn) . "</p>";
    }
}

// Close the database connection
mysqli_close($conn);
?>
