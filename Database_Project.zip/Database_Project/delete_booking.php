<?php
include "connect.php";

if (isset($_GET['id'])) {
    $booking_id = intval($_GET['id']);
    
    $sql = "DELETE FROM Booking WHERE Booking_id = $booking_id";
    
    if (mysqli_query($conn, $sql)) {
        header('Location: view_bookings.php');
        exit();
    } else {
        echo "Error deleting data: " . mysqli_error($conn);
    }
} else {
    echo "No booking ID provided.";
}

mysqli_close($conn);
?>
