<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hotel_schema";

$conn = mysqli_connect($servername,$username,$password,$dbname);
if ($conn) {
    $message = "Connection Successful";
} 
else {
    $message = "Not Connected";
}
?>