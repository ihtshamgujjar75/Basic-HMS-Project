<?php
include "connect.php";

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    $sql = "DELETE FROM Rooms WHERE room_id = $id";

    if (mysqli_query($conn, $sql)) {
        header('Location: select_room.php');
        exit();
    } else {
        echo "Error deleting data: " . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>
