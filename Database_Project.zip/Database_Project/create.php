<?php
include "connect.php";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    // Retrieve form inputs without escaping
    $first_name = $_POST['fname'];
    $last_name = $_POST['lname'];
    $email = $_POST['email'];
    $contact = $_POST['phone'];
    $city = $_POST['city'];
    $zip = $_POST['zip'];
    $state = $_POST['state'];

    // Construct the SQL query
    $sql = "INSERT INTO Guests (First_name, Last_name, Email, contact, city, zipCode, state) 
            VALUES ('$first_name', '$last_name', '$email', '$contact', '$city', '$zip', '$state')";

    // Execute the query and handle the result
    if (mysqli_query($conn, $sql)) {
        $guest_id = mysqli_insert_id($conn); // Get the ID of the newly inserted guest
        header("Location: view_guests.php"); // Redirect to view_guests.php without guest_id
        exit();
    } else {
        echo "Error inserting data: " . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>
