<?php
include "connect.php";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    // Collect and sanitize form data
    $booking_id = intval($_POST['booking_id']);
    $total_amount = intval($_POST['total_amount']);
    $payment_date = mysqli_real_escape_string($conn, $_POST['payment_date']);
    $payment_method = mysqli_real_escape_string($conn, $_POST['payment_method']);
    $advance = intval($_POST['advance']);
    $guest_id = intval($_POST['guest_id']);

    // Insert query
    $sql = "INSERT INTO billings (booking_id, Total_amount, payment_date, payment_method, advance, guest_id) 
            VALUES ('$booking_id', '$total_amount', '$payment_date', '$payment_method', '$advance', '$guest_id')";

    // Execute query and handle errors
    if (mysqli_query($conn, $sql)) {
        header('Location: select_billing.php');
        exit();
    } else {
        echo "<p>Error inserting data: " . mysqli_error($conn) . "</p>";
    }
}

// Close the database connection
mysqli_close($conn);
?>
