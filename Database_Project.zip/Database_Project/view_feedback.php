<?php
include "connect.php";

$result = mysqli_query($conn, "SELECT * FROM feedback ORDER BY feedback_date DESC");

mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Feedback</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: #f4f4f4;
            color: #333;
        }
        table {
            width: 80%;
            margin: 40px auto;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #007bff;
            color: #fff;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        .button {
            display: inline-block;
            background-color: #28a745;
            color: #fff;
            padding: 6px 12px;
            text-decoration: none;
            border-radius: 4px;
            text-align: center;
        }
        .button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <table>
        <tr>
            <th>Feedback ID</th>
            <th>Feedback Date</th>
            <th>Rating</th>
            <th>Comments</th>
            <th>Booking ID</th>
            <th>Guest ID</th>
        </tr>
        <?php
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>
                        <td>" . $row['feedback_id'] . "</td>
                        <td>" . $row['feedback_date'] . "</td>
                        <td>" . $row['rating'] . "</td>
                        <td>" . $row['comments'] . "</td>
                        <td>" . $row['booking_id'] . "</td>
                        <td>" . $row['guest_id'] . "</td>
                    </tr>";
            }
        } else {
            echo "<tr><td colspan='6' style='text-align: center;'>No records found.</td></tr>";
        }
        ?>
    </table>
    
</body>
</html>
