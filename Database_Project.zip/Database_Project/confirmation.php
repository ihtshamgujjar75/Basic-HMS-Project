<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Added Confirmation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('hotel.JPG'); /* Replace with your background image */
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            max-width: 500px;
            margin: 0 auto;
        }
        h1 {
            font-size: 24px;
            margin-bottom: 20px;
        }
        p {
            font-size: 18px;
            margin-bottom: 30px;
        }
        .button {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            font-size: 16px;
            cursor: pointer;
        }
        .button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Thank You for Your Reservation</h1>
        <?php
        if (isset($_GET['booking_id'])) {
            $booking_id = intval($_GET['booking_id']);
            echo "<p>Thank you for your reservation. Your booking ID is <strong>$booking_id</strong>. Please check your billing with this ID.</p>";
        } else {
            echo "<p>There was an error with your reservation. Please try again.</p>";
        }
        ?>
        <a href="dashboard.html" class="button">Back to Dashboard</a> <!-- Change 'dashboard.html' to your actual dashboard page -->
    </div>
</body>
</html>
