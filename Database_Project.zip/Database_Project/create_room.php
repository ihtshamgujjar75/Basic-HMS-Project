<?php
include "connect.php";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $room_number = mysqli_real_escape_string($conn, $_POST['room_number']);
    $room_type = mysqli_real_escape_string($conn, $_POST['room_type']);
    $rate_per_night = mysqli_real_escape_string($conn, $_POST['rate_per_night']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);

    $sql = "INSERT INTO Rooms (room_number, room_type, rate_per_night, Status, Location)
            VALUES ('$room_number', '$room_type', '$rate_per_night', '$status', '$location')";

    if (mysqli_query($conn, $sql)) {
        header('Location: select_room.php');
        exit();
    } else {
        echo "Error inserting data: " . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Room</title>
    <style>
        body { font-family: 'Lato', sans-serif; margin: 0; padding: 0; background-image: url('5.jpg'); background-size: cover; background-repeat: no-repeat; color: white; height: 100vh; }
        form { background-color: rgba(0, 0, 0, 0.7); padding: 20px; border-radius: 8px; width: 25%; margin: 80px auto; }
        input { display: block; width: 100%; margin-bottom: 20px; padding: 5px; box-sizing: border-box; }
        .button { background-color: red; color: white; }
        .button:hover { background-color: gray; color: white; }
    </style>
</head>
<body>
    <form action="create_room.php" method="post">
        <fieldset>
            <legend>Create New Room</legend>
            Room Number: <input type="number" name="room_number" required>
            Room Type: <input type="text" name="room_type" required>
            Rate per Night: <input type="number" name="rate_per_night" required>
            Status: <input type="text" name="status" required>
            Location: <input type="text" name="location" required>
            <input type="submit" value="Submit" class="button">
        </fieldset>
    </form>
</body>
</html>
