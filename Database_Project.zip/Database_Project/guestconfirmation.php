<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Confirmation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('hotel.JPG'); /* Replace with your background image */
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            max-width: 500px;
            margin: 0 auto;
        }
        h1 {
            font-size: 24px;
            margin-bottom: 20px;
        }
        p {
            font-size: 18px;
            margin-bottom: 30px;
        }
        .button {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            font-size: 16px;
            cursor: pointer;
        }
        .button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Thank You for Choosing Our Hotel</h1>
        <?php
        if (isset($_GET['guest_id'])) {
            $guest_id = intval($_GET['guest_id']);
            echo "<p>Thank you for registering. Your guest ID is <strong>$guest_id</strong>. For booking and other services, continue to the dashboard.</p>";
        } else {
            echo "<p>There was an error with your registration. Please try again.</p>";
        }
        ?>
        <a href="dashboard.html" class="button">Go to Dashboard</a>
    </div>
</body>
</html>
