<?php

$name = $_REQUEST['name'];
$fatherName = $_REQUEST['fatherName'];
$phone = $_REQUEST['phone'];
$email = $_REQUEST['email'];
$password = $_REQUEST['password'];

echo"  <nav class='navbar'>
        <h1>Tech <span style='color:red'>World</span></h1>
        <ul style='display: flex; justify-content:space-evenly; list-style: none; margin-left:70%'>
            <li>Log out</li>       
        </ul>
    </nav>";

echo"  <table border='1' style='background-color: silver; border-collapse: separate; border-spacing: 10px;'>
    <thead>
        <th>S.No</th>
        <th>Information</th>
        <th>Value</th>
    </thead>
    <tbody>
        <tr style='background-color: lightgrey; color: darkblue; border: 2px solid black;'>
            <td>1</td>
            <td>Name</td>
            <td>$name</td>
        </tr>
        <tr style='color: darkblue; border: 2px solid black;'>
            <td>2</td>
            <td>Father Name</td>
            <td>$fatherName</td>
        </tr>
        <tr style='background-color: lightgrey; color: darkblue; border: 2px solid black;'>
            <td>3</td>
            <td>Email</td>
            <td>$email</td>
        </tr>
        <tr style='color: darkblue; border: 2px solid black;'>
            <td>4</td>
            <td>Phone</td>
            <td>$phone</td>
        </tr>
        <tr style='background-color: lightgrey; color: darkblue; border: 2px solid black;'>
            <td>5</td>
            <td>Password</td>
            <td>$password</td>
        </tr>
    </tbody>
</table>";

echo" <style>
body{
    font-family: lato;
    margin: 0;
    padding: 0;
    background-image: url('1.jpg');
    background-size: cover;
    background-repeat: no-repeat;
    color: white;
 }
.navbar {
    background-color:black;
    padding :5px;
    display: flex;
    justify-content: space-between;
    flex-direction:row;
}
.navbar li {
    background-color:black;
    margin-right :6px;
    color: white;
    list-style-type: none;
    flex-direction:row;
}
.navbar h1 {
    margin-left:20px;
}
table {
    margin-top: 20%;
    margin-left: 35%;
    border-color: black ;
    border:1 px solid;
}
</style>";
?>
