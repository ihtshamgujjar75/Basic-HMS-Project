<?php
include "connect.php";

if (isset($_GET['id'])) {
    $booking_id = intval($_GET['id']);

    $result = mysqli_query($conn, "SELECT * FROM Booking WHERE Booking_id = $booking_id");
    if (mysqli_num_rows($result) == 1) {
        $booking = mysqli_fetch_assoc($result);
    } else {
        echo "Booking not found.";
        exit();
    }
} else {
    echo "No booking ID provided.";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $guest_id = intval($_POST['guest_id']);
    $room_id = intval($_POST['room_id']);
    $check_in = mysqli_real_escape_string($conn, $_POST['check_in']);
    $check_out = mysqli_real_escape_string($conn, $_POST['check_out']);
    $booking_date = mysqli_real_escape_string($conn, $_POST['booking_date']);
    $payment_status = mysqli_real_escape_string($conn, $_POST['payment_status']);

    $sql = "UPDATE Booking SET 
                guest_id = '$guest_id',
                room_id = '$room_id',
                check_in = '$check_in',
                check_out = '$check_out',
                booking_date = '$booking_date',
                payment_status = '$payment_status'
            WHERE Booking_id = $booking_id";

    if (mysqli_query($conn, $sql)) {
        header('Location: view_bookings.php');
        exit();
    } else {
        echo "Error updating data: " . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Booking</title>
    <style>
        body {
            font-family: lato;
            margin: 0;
            padding: 0;
            background-image: url('5.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            color: white;
            height: 100vh;
        }
        form {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 20px;
            border-radius: 8px;
            width: 30%;
            margin: 80px auto;
        }
        input, select {
            display: block;
            width: 100%;
            margin-bottom: 20px;
            padding: 5px;
            box-sizing: border-box;
        }
        .button {
            background-color: red;
            color: white;
        }
        .button:hover {
            background-color: gray;
            color: white;
        }
    </style>
</head>
<body>
    <form action="update_booking.php?id=<?php echo $booking['Booking_id']; ?>" method="post">
        <fieldset>
            <legend>Update Booking</legend>
            Guest ID:
            <input type="number" id="guest_id" name="guest_id" value="<?php echo $booking['guest_id']; ?>" required>
            Room ID:
            <input type="number" id="room_id" name="room_id" value="<?php echo $booking['room_id']; ?>" >
            Check-in Date:
            <input type="date" id="check_in" name="check_in" value="<?php echo $booking['Check_in']; ?>" >
            Check-out Date:
            <input type="date" id="check_out" name="check_out" value="<?php echo $booking['check_out']; ?>" >
            Booking Date:
            <input type="date" id="booking_date" name="booking_date" value="<?php echo $booking['Booking_date']; ?>" >
            Payment Status:
            <select id="payment_status" name="payment_status" required>
                <option value="Paid" <?php echo $booking['payment_status'] === 'Paid' ? 'selected' : ''; ?>>Paid</option>
                <option value="Unpaid" <?php echo $booking['payment_status'] === 'Unpaid' ? 'selected' : ''; ?>>Unpaid</option>
            </select>
            <input type="submit" value="Update Booking" class="button">
        </fieldset>
    </form>
</body>
</html>
