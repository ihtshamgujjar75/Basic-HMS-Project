<?php
include "connect.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $booking_id = intval($_POST['booking_id']);

    // Fetch billing details based on booking ID
    $sql = "SELECT * FROM billings WHERE booking_id = $booking_id";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        $billing = mysqli_fetch_assoc($result);
    } else {
        $error_message = "No billing details found for Booking ID $booking_id.";
    }

    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Billing Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 80%;
            max-width: 600px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .button {
            display: inline-block;
            background-color: #007bff;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
        }
        .button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Billing Details</h2>
        <?php if (isset($error_message)): ?>
            <p><?php echo $error_message; ?></p>
            <a href="check_billing.php" class="button">Try Again</a>
        <?php elseif (isset($billing)): ?>
            <table>
                <tr>
                    <th>Bill ID</th>
                    <th>Booking ID</th>
                    <th>Total Amount</th>
                    <th>Payment Date</th>
                    <th>Payment Method</th>
                    <th>Advance</th>
                    <th>Guest ID</th>
                </tr>
                <tr>
                    <td><?php echo $billing['bill_id']; ?></td>
                    <td><?php echo $billing['booking_id']; ?></td>
                    <td><?php echo $billing['Total_amount']; ?></td>
                    <td><?php echo $billing['payment_date']; ?></td>
                    <td><?php echo $billing['payment_method']; ?></td>
                    <td><?php echo $billing['advance']; ?></td>
                    <td><?php echo $billing['guest_id']; ?></td>
                </tr>
            </table>
            <a href="checkbilling.php" class="button">Check Another</a>
        <?php endif; ?>
    </div>
</body>
</html>
