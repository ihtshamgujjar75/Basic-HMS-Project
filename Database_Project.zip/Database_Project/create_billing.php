<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Billing</title>
    <style>
        body {
            font-family: lato;
            margin: 0;
            padding: 0;
            background-image: url('5.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            color: white;
            height: 100vh;
        }
        form {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 20px;
            border-radius: 8px;
            width: 30%;
            margin: 80px auto;
        }
        input {
            display: block;
            width: 100%;
            margin-bottom: 20px;
            padding: 5px;
            box-sizing: border-box;
        }
        .button {
            background-color: red;
            color: white;
        }
        .button:hover {
            background-color: gray;
            color: white;
        }
    </style>
</head>
<body>
    <form action="store_billing.php" method="post">
        <fieldset>
            <legend>Create Billing</legend>
            Booking ID:
            <input type="number" id="booking_id" name="booking_id" placeholder="Booking ID" required>
            Total Amount:
            <input type="number" id="total_amount" name="total_amount" placeholder="Total Amount" required>
            Payment Date:
            <input type="date" id="payment_date" name="payment_date" required>
            Payment Method:
            <input type="text" id="payment_method" name="payment_method" placeholder="Payment Method" required>
            Advance:
            <input type="number" id="advance" name="advance" placeholder="Advance Amount" required>
            Guest ID:
            <input type="number" id="guest_id" name="guest_id" placeholder="Guest ID" required>
            <input type="submit" value="Add Billing" class="button">
        </fieldset>
    </form>
</body>
</html>
