<?php
include "connect.php";

$result = mysqli_query($conn, "SELECT * FROM Booking");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Records</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background: #f0f0f0;
            color: #333;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        table {
            width: 80%;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin: 20px 0;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #007bff;
            color: #fff;
        }
        .even-row {
            background-color: #f9f9f9;
        }
        .odd-row {
            background-color: #ffffff;
        }
        tr:hover {
            background-color: #e0e0e0;
        }
        .button {
            display: inline-block;
            background-color: #28a745;
            color: #fff;
            padding: 6px 12px;
            text-decoration: none;
            border-radius: 4px;
            margin: 2px;
            text-align: center;
        }
        .button:hover {
            background-color: #218838;
        }
        .actions {
            text-align: center;
        }
    </style>
</head>
<body>
    <table>
        <tr>
            <th>Booking ID</th>
            <th>Guest ID</th>
            <th>Room ID</th>
            <th>Check-in Date</th>
            <th>Check-out Date</th>
            <th>Booking Date</th>
            <th>Payment Status</th>
            <th>Actions</th>
        </tr>
        <?php
        $rowClass = 'odd-row';
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr class='$rowClass'>
                        <td>" . $row['Booking_id'] . "</td>
                        <td>" . $row['guest_id'] . "</td>
                        <td>" . $row['room_id'] . "</td>
                        <td>" . $row['Check_in'] . "</td>
                        <td>" . $row['check_out'] . "</td>
                        <td>" . $row['Booking_date'] . "</td>
                        <td>" . $row['payment_status'] . "</td>
                        <td class='actions'>
                            <a href='update_booking.php?id=" . $row['Booking_id'] . "' class='button'>Edit</a>
                            <a href='delete_booking.php?id=" . $row['Booking_id'] . "' class='button' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                           
                            </td>
                    </tr>";
                $rowClass = ($rowClass === 'odd-row') ? 'even-row' : 'odd-row';
            }
        } else {
            echo "<tr><td colspan='8' style='text-align: center;'>No records found.</td></tr>";
        }
        ?>
    </table>
    <a href="create_booking.php" class="button" style="margin-top: 20px;">Add New Booking</a>
</body>
</html>
<?php
mysqli_close($conn);
?>
