<?php
include "connect.php";

// Fetch housekeeping records
$result = mysqli_query($conn, "SELECT * FROM housekeepingschedule");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Housekeeping Schedule</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            flex-direction: column;
            align-items: center;
            margin: 0;
        }
        table {
            width: 80%;
            margin-top: 20px;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        th, td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #007bff;
            color: #fff;
        }
        .even-row {
            background-color: #f9f9f9;
        }
        .odd-row {
            background-color: #fff;
        }
        tr:hover {
            background-color: #e0e0e0;
        }
        .button {
            display: inline-block;
            background-color: #007bff;
            color: #fff;
            padding: 6px 12px;
            text-decoration: none;
            border-radius: 4px;
            margin: 2px;
            text-align: center;
        }
        .button:hover {
            background-color: #0056b3;
        }
        .actions {
            text-align: center;
        }
    </style>
</head>
<body>
    <h1>Manage Housekeeping Schedule</h1>
    <table>
        <tr>
            <th>Schedule ID</th>
            <th>Room ID</th>
            <th>Schedule Date</th>
            <th>Housekeeper Name</th>
            <th>Task Description</th>
            <th>Schedule Status</th>
            <th>Actions</th>
        </tr>
        <?php
        $rowClass = 'odd-row';
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr class='$rowClass'>
                        <td>" . $row['schedule_id'] . "</td>
                        <td>" . $row['room_id'] . "</td>
                        <td>" . $row['schedule_date'] . "</td>
                        <td>" . $row['housekeeper_name'] . "</td>
                        <td>" . $row['Task_description'] . "</td>
                        <td>" . $row['schedule_status'] . "</td>
                        <td class='actions'>
                            <a href='update_housekeeping.php?schedule_id=" . $row['schedule_id'] . "' class='button'>Edit</a>
                            <a href='delete_housekeeping.php?schedule_id=" . $row['schedule_id'] . "' class='button' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                        </td>
                    </tr>";
                $rowClass = ($rowClass === 'odd-row') ? 'even-row' : 'odd-row';
            }
        } else {
            echo "<tr><td colspan='7' style='text-align: center;'>No records found.</td></tr>";
        }
        ?>
    </table>
    <a href="create_housekeeping.html" class="button" style="margin-top: 20px;">Add New Schedule</a>
</body>
</html>
<?php
mysqli_close($conn);
?>
