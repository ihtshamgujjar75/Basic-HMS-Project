<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <style>
        body {
            font-family: 'Lato', sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('3.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        form {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 20px;
            border-radius: 8px;
            width: 25%;
            margin: auto;
        }

        fieldset {
            border: 0;
        }

        legend {
            color: white;
            font-size: 1.5em;
        }

        label {
            display: block;
            margin-bottom: 5px;
            color: white;
        }

        input {
            display: block;
            width: 100%;
            margin-bottom: 20px;
            padding: 10px;
            box-sizing: border-box;
        }

        .button {
            background-color: red;
            color: white;
            border: none;
            padding: 10px;
            cursor: pointer;
            border-radius: 5px;
        }

        .button:hover {
            background-color: gray;
        }
    </style>
</head>
<body>
    <form action="admin_login.php" method="post">
        <fieldset>
            <legend>Admin Login</legend>
            Username:
            <input type="text" id="username" name="username" placeholder="Enter Your Username" required>
            Password:
            <input type="password" id="password" name="password" placeholder="Enter Your Password" required>
            <input type="submit" value="Login" class="button">
        </fieldset>
    </form>
</body>
</html>

<?php
session_start();

// Define admin credentials
$admin_username = "admin";
$admin_password = "hotel123";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check credentials
    if ($username === $admin_username && $password === $admin_password) {
        // Start a session and redirect to the dashboard
        $_SESSION['loggedin'] = true;
        header('Location: dashboard.php');
        exit();
    } else {
        echo "<p style='color: red; text-align: center;'>Invalid Username or Password</p>";
    }
}
?>

