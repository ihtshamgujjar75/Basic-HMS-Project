<?php
include "connect.php";

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    if ($_SERVER['REQUEST_METHOD'] == "POST") {
        $room_number = mysqli_real_escape_string($conn, $_POST['room_number']);
        $room_type = mysqli_real_escape_string($conn, $_POST['room_type']);
        $rate_per_night = mysqli_real_escape_string($conn, $_POST['rate_per_night']);
        $status = mysqli_real_escape_string($conn, $_POST['status']);
        $location = mysqli_real_escape_string($conn, $_POST['location']);

        $sql = "UPDATE Rooms SET room_number = '$room_number', room_type = '$room_type', rate_per_night = '$rate_per_night', Status = '$status', Location = '$location' WHERE room_id = $id";

        if (mysqli_query($conn, $sql)) {
            header('Location: select_room.php');
            exit();
        } else {
            echo "Error updating record: " . mysqli_error($conn);
        }
    }

    $result = mysqli_query($conn, "SELECT * FROM Rooms WHERE room_id = $id");
    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
    } else {
        echo "Record not found.";
        exit();
    }
} else {
    echo "No ID provided.";
    exit();
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Room</title>
    <style>
        body { font-family: 'Lato', sans-serif; margin: 0; padding: 0; background-image: url('5.jpg'); background-size: cover; background-repeat: no-repeat; color: white; height: 100vh; }
        form { background-color: rgba(0, 0, 0, 0.7); padding: 20px; border-radius: 8px; width: 25%; margin: 80px auto; }
        input { display: block; width: 100%; margin-bottom: 20px; padding: 5px; box-sizing: border-box; }
        .button { background-color: red; color: white; }
        .button:hover { background-color: gray; color: white; }
    </style>
</head>
<body>
    <form action="edit_room.php?id=<?php echo $id; ?>" method="post">
        <fieldset>
            <legend>Edit Room</legend>
            Room Number: <input type="number" name="room_number" value="<?php echo htmlspecialchars($row['room_number']); ?>" required>
            Room Type: <input type="text" name="room_type" value="<?php echo htmlspecialchars($row['room_type']); ?>" required>
            Rate per Night: <input type="number" name="rate_per_night" value="<?php echo htmlspecialchars($row['rate_per_night']); ?>" required>
            Status: <input type="text" name="status" value="<?php echo htmlspecialchars($row['Status']); ?>" required>
            Location: <input type="text" name="location" value="<?php echo htmlspecialchars($row['Location']); ?>" required>
            <input type="submit" value="Update" class="button">
        </fieldset>
    </form>
</body>
</html>
