<?php
include "connect.php";

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    $sql = "DELETE FROM billings WHERE bill_id = $id";

    if (mysqli_query($conn, $sql)) {
        header('Location: select_billing.php');
        exit();
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
} else {
    echo "No billing ID provided.";
}

mysqli_close($conn);
?>
