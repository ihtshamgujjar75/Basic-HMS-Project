<?php
include "connect.php";

$result = mysqli_query($conn, "SELECT * FROM guests");

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Guests</title>
    <style>
        body { font-family: 'Arial', sans-serif; margin: 0; padding: 0; background: #f0f0f0; color: #333; display: flex; flex-direction: column; justify-content: center; align-items: center; height: 100vh; }
        table { width: 80%; border-collapse: collapse; background: #fff; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); margin: 20px 0; }
        th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: #007bff; color: #fff; }
        .even-row { background-color: #f9f9f9; }
        .odd-row { background-color: #ffffff; }
        tr:hover { background-color: #e0e0e0; }
        .button { display: inline-block; background-color: #28a745; color: #fff; padding: 6px 12px; text-decoration: none; border-radius: 4px; margin: 2px; text-align: center; }
        .button:hover { background-color: #218838; }
        .actions { text-align: center; }
    </style>
</head>
<body>
    <table>
        <tr>
            <th>ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Contact</th>
            <th>City</th>
            <th>State</th>
            <th>Zip Code</th>
            <th>Actions</th>
        </tr>
        <?php
        $rowClass = 'odd-row';
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr class='$rowClass'>
                        <td>" . $row['guest_id'] . "</td>
                        <td>" . $row['First_name'] . "</td>
                        <td>" . $row['Last_name'] . "</td>
                        <td>" . $row['Email'] . "</td>
                        <td>" . $row['contact'] . "</td>
                        <td>" . $row['city'] . "</td>
                        <td>" . $row['state'] . "</td>
                        <td>" . $row['zipCode'] . "</td>
                        <td class='actions'>
                            <a href='edit_guest.php?id=" . $row['guest_id'] . "' class='button'>Edit</a>
                            <a href='delete_guest.php?id=" . $row['guest_id'] . "' class='button' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                        </td>
                    </tr>";
                $rowClass = ($rowClass === 'odd-row') ? 'even-row' : 'odd-row';
            }
        } else {
            echo "<tr><td colspan='9' style='text-align: center;'>No records found.</td></tr>";
        }
        ?>
    </table>
    <a href="create_guest.php" class="button" style="margin-top: 20px;">Add New Guest</a>
</body>
</html>
