<?php
include "connect.php";

if (isset($_GET['schedule_id'])) {
    $schedule_id = intval($_GET['schedule_id']);
    
    // Delete query
    $sql = "DELETE FROM housekeepingschedule WHERE schedule_id = $schedule_id";

    if (mysqli_query($conn, $sql)) {
        header('Location: manage_housekeeping.php');
        exit();
    } else {
        echo "<p>Error deleting record: " . mysqli_error($conn) . "</p>";
    }
} else {
    echo "No schedule ID provided.";
}

// Close the database connection
mysqli_close($conn);
?>
