<?php
include "connect.php";

// Fetch existing record if ID is provided
$schedule_id = isset($_GET['schedule_id']) ? intval($_GET['schedule_id']) : 0;
if ($schedule_id > 0) {
    $result = mysqli_query($conn, "SELECT * FROM housekeepingschedule WHERE schedule_id = $schedule_id");
    if (mysqli_num_rows($result) == 1) {
        $record = mysqli_fetch_assoc($result);
    } else {
        echo "Record not found.";
        exit();
    }
}

// Handle form submission for updating
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $schedule_date = mysqli_real_escape_string($conn, $_POST['schedule_date']);
    $housekeeper_name = mysqli_real_escape_string($conn, $_POST['housekeeper_name']);
    $task_description = mysqli_real_escape_string($conn, $_POST['task_description']);
    $schedule_status = mysqli_real_escape_string($conn, $_POST['schedule_status']);

    $sql = "UPDATE housekeepingschedule
            SET schedule_date = '$schedule_date', housekeeper_name = '$housekeeper_name', task_description = '$task_description', schedule_status = '$schedule_status'
            WHERE schedule_id = $schedule_id";

    if (mysqli_query($conn, $sql)) {
        header('Location: manage_housekeeping.php');
        exit();
    } else {
        echo "<p>Error updating record: " . mysqli_error($conn) . "</p>";
    }
}

mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Housekeeping Schedule</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }
        input, textarea {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        h1 {
            margin-bottom: 20px;
            font-size: 24px;
            text-align: center;
        }
    </style>
</head>
<body>
    <form action="update_housekeeping.php?schedule_id=<?php echo $schedule_id; ?>" method="post">
        <h1>Update Housekeeping Schedule</h1>
        <label for="schedule_date">Schedule Date:</label>
        <input type="date" id="schedule_date" name="schedule_date" value="<?php echo htmlspecialchars($record['schedule_date']); ?>" required>
        
        <label for="housekeeper_name">Housekeeper Name:</label>
        <input type="text" id="housekeeper_name" name="housekeeper_name" value="<?php echo htmlspecialchars($record['housekeeper_name']); ?>" required>
        
        <label for="task_description">Task Description:</label>
        <textarea id="task_description" name="Task_description" rows="4" required><?php echo htmlspecialchars($record['task_description']); ?></textarea>
        
        <label for="schedule_status">Schedule Status:</label>
        <input type="text" id="schedule_status" name="schedule_status" value="<?php echo htmlspecialchars($record['schedule_status']); ?>" required>
        
        <input type="submit" value="Update Schedule">
    </form>
</body>
</html>
