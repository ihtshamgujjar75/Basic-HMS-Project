<?php
include "connect.php";

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    if ($_SERVER['REQUEST_METHOD'] == "POST") {
        $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
        $last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $contact = mysqli_real_escape_string($conn, $_POST['contact']);
        $city = mysqli_real_escape_string($conn, $_POST['city']);
        $state = mysqli_real_escape_string($conn, $_POST['state']);
        $zipCode = mysqli_real_escape_string($conn, $_POST['zipCode']);

        $sql = "UPDATE Guests SET First_name = '$first_name', Last_name = '$last_name', Email = '$email', contact = '$contact', city = '$city', state = '$state', zipCode = '$zipCode' WHERE guest_id = $id";

        if (mysqli_query($conn, $sql)) {
            header('Location: view_guests.php');
            exit();
        } else {
            echo "Error updating record: " . mysqli_error($conn);
        }
    }

    $result = mysqli_query($conn, "SELECT * FROM Guests WHERE guest_id = $id");
    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
    } else {
        echo "Record not found.";
        exit();
    }
} else {
    echo "No ID provided.";
    exit();
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Guest</title>
    <style>
        body { font-family: 'Lato', sans-serif; margin: 0; padding: 0; background-image: url('5.jpg'); background-size: cover; background-repeat: no-repeat; color: white; height: 100vh; }
        form { background-color: rgba(0, 0, 0, 0.7); padding: 20px; border-radius: 8px; width: 25%; margin: 80px auto; }
        input { display: block; width: 100%; margin-bottom: 20px; padding: 5px; box-sizing: border-box; }
        .button { background-color: red; color: white; }
        .button:hover { background-color: gray; color: white; }
    </style>
</head>
<body>
    <form action="edit_guest.php?id=<?php echo $id; ?>" method="post">
        <fieldset>
            <legend>Edit Guest</legend>
            First Name: <input type="text" name="first_name" value="<?php echo htmlspecialchars($row['First_name']); ?>" required>
            Last Name: <input type="text" name="last_name" value="<?php echo htmlspecialchars($row['Last_name']); ?>" required>
            Email: <input type="email" name="email" value="<?php echo htmlspecialchars($row['Email']); ?>" required>
            Contact: <input type="tel" name="contact" value="<?php echo htmlspecialchars($row['contact']); ?>" required>
            City: <input type="text" name="city" value="<?php echo htmlspecialchars($row['city']); ?>" required>
            State: <input type="text" name="state" value="<?php echo htmlspecialchars($row['state']); ?>" required>
            Zip Code: <input type="text" name="zipCode" value="<?php echo htmlspecialchars($row['zipCode']); ?>" required>
            <input type="submit" value="Update" class="button">
        </fieldset>
    </form>
</body>
</html>
