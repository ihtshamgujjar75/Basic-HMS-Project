<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple Form</title>
    <style>
        body {
            font-family: lato;
            margin: 0;
            padding: 0;
            background-image: url('2.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            color: white;
            height: 100vh;
        }

        form {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 20px;
            border-radius: 8px;
            width: 25%;
            margin: 80px auto;
        }

        fieldset {
            border: 0;
        }

        legend {
            color: white;
        }

        label {
            display: block;
            margin-bottom: 5px;
            color: white;
        }

        input {
            display: block;
            width: 100%;
            margin-bottom: 20px;
            padding: 5px;
            box-sizing: border-box;
        }

        .button {
            background-color: red;
            color: white;
        }

        .button:hover {
            background-color: gray;
            color: white;
        }
    </style>
</head>
<body>
    <form action="create.php" method="post">
        <fieldset>
            <legend>Registration Form</legend>
            First Name:
            <input type="text" id="fname" name="fname" placeholder="First Name" required>

            Last Name:
            <input type="text" id="lname" name="lname" placeholder="Last Name" required>

            Phone:
            <input type="tel" id="phone" name="phone" placeholder="Phone" required>

            Email:
            <input type="email" id="email" name="email" placeholder="Email" required>

            City:
            <input type="text" id="city" name="city" placeholder="City" required>

            Zipcode:
            <input type="text" id="zip" name="zip" placeholder="Zipcode" required>

            State:
            <input type="text" id="state" name="state" placeholder="State" required>

            <input type="submit" value="Submit" class="button">
        </fieldset>
    </form>
</body>
</html>
