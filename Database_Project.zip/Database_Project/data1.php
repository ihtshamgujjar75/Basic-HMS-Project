<?php

$name = $_POST['name'];
$password = $_POST['password'];

echo"  <table border='1' style='background-color: silver; border-collapse: separate; border-spacing: 10px; width: 40%; align:center'>
    <thead>
        <th>S.No</th>
        <th>Information</th>
        <th>Value</th>
    </thead>
    <tbody>
        <tr style='background-color: lightgrey; color: darkblue; border: 2px solid black;'>
            <td>1</td>
            <td>Name</td>
            <td>$name</td>
        </tr>
        <tr style='background-color: lightgrey; color: darkblue; border: 2px solid black;'>
        <td>2</td>
        <td>Email</td>
        <td>$password</td>
    </tr>
    </tbody>
    </table>";
    
    echo" <style>
    body{
        font-family: lato;
        margin: 0;
        padding: 0;
        background-image: url('exective.jpg');
        background-size: cover;
        background-repeat: no-repeat;
        color: white;
     }
    
    table {
        margin-top: 20%;
        margin-left: 35%;
        border-color: black ;
        border:1 px solid;
    }
    </style>";
    ?>
    